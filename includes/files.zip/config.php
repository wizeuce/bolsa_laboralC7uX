<?php
	if(!defined('RUTAGENERAL')) define("RUTAGENERAL", "http://localhost/bolsa/");
	
	if(!defined('SERVIDOR')) define("SERVIDOR", "localhost");	
	if(!defined('BD')) define("BD", "bolsaupeu");
	if(!defined('USUARIO')) define("USUARIO", "root");
	if(!defined('PASSWORD')) define("PASSWORD", "");
?>
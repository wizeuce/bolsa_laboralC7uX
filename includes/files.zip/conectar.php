<?php
include_once ("config.php");

function conectar(){
	$link = new mysqli(SERVIDOR, USUARIO,PASSWORD, BD);
	if ($link  -> connect_errno) {
		die( "Error en la conexión a la Base de Datos.");
	}else{
		mysqli_query($link,"SET NAMES 'utf8'");
		mysqli_set_charset($link, "utf8");
		date_default_timezone_set("America/Lima");		
		return $link;
	}
}
?>